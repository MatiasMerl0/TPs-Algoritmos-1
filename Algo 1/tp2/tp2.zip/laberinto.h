#ifndef GENERADOR_LABERINTO_H
#define GENERADOR_LABERINTO_H

#define TAMANIO 15
#define PARED '#'
#define VACIO ' '

void inicializar_paredes_laberinto(char laberinto[TAMANIO][TAMANIO]);


#endif 